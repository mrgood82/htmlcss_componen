## Color Gradient Generator

program ini dibuat dengan bahasa pemrograman javascript. program ini akan memunculkan warna gradient baru ketika tombol generate ditekan.

### dibuat dengan berikut 

* HTML
* CSS
  * [Bootstrap](https://getbootstrap.com)
* Javascript

### lainnya

* [SweetAlert2](https://sweetalert2.github.io)
* handphone
* code editor (Acode)
* edit gambar (Pixellab)

### preview

![result](https://github.com/candradwicahyo/color-gradient-generator/blob/master/preview.jpg)

[tekan link ini untuk mencoba program ini](https://candradwicahyo.github.io/color-gradient-generator)

> dibuat oleh **candra dwi cahyo**