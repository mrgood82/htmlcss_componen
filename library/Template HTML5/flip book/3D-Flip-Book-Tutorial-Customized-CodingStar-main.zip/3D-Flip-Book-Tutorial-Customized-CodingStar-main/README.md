# 3D-Flip-Book-Tutorial-Customized

[view in browser](https://codingstar-jason.github.io/3D-Flip-Book-Tutorial-Customized-CodingStar/)

### Shoutout 🙌

Little Dog Photo by David Clarke on Unsplash
