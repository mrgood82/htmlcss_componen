<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Sistem Pakar </title>
<style type="text/css">

</style>
</head>
<body>
<h2>Selamat datang Admin</h2><hr><br>
<div class="CSSTableGenerator">
<table width="200" border="1" align="center">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td align="center" valign="bottom"><strong><a href="haladmin.php?top=penyakit_solusi.php"><span class="t">Penyakit & Solusi </span></a></strong></td>
  </tr>
  <tr>
    <td align="center" valign="bottom"><strong><a href="haladmin.php?top=gejala.php" ><span class="t">Gejala</span></a></strong></td>
  </tr>
  <tr>
    <td align="center" valign="bottom"><strong><a href="haladmin.php?top=relasi.php"><span class="t">Relasi</span></a></strong></td>
  </tr>
  <tr>
    <td align="center" valign="bottom"><strong><a href="haladmin.php?top=lapgejala.php"><span class="t">Laporan Gejala</span></a></strong></td>
  </tr>
  <tr>
    <td align="center" valign="bottom"><strong><a href="haladmin.php?top=lapuser.php"><span class="t">Laporan User</span></a></strong></td>
  </tr>
</table>

</div>
<table width="100%" height="25" align="center">
</table>
</body>
</html>
