<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
<style type="text/css">
<!--
.style2 {font-size: 10px}
.style3 {
	font-size: 10px;
	font-style: italic;
	font-weight: bold;
}
-->
</style>
</head>

<body><center>
<span class="style3"><img src="image/footer.jpg" width="900" height="100"></span>
</center>
</body>
</html>
