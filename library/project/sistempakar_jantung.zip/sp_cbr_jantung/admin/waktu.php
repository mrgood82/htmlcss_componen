<HTML>
<HEAD>
<TITLE></TITLE>
</HEAD>
<font face="Arial" font color="#000" style='font-size: 8pt;'>
Jam
<?php
/*function jam()
{
global $jj,$mm;

$saat_ini=getdate();
$jj=$saat_ini['hours'];
$mm=$saat_ini['minutes'];
}
jam();
echo"$jj : $mm ";

*/?>
<?php
printf (" %s",
date ("h:m a"));
?>
</font>
</BODY>
</HTML>