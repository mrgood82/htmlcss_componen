<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Sistem Pakar Penyakit Jantung</title>
<style type="text/css">
<!--
.style1 {font-family: Arial, Helvetica, sans-serif}
.style10 {font-family: Verdana, Arial, Helvetica, sans-serif}
-->
</style>
</head>

<body>
<p>
  <marquee scrolldelay='150'>
  <span class="style1">..:: </span><span class="style10">Selamat Datang di Website Sistem Pakar Penyakit Jantung </span><span class="style1">::.. </span>
  </marquee>
</p>
</body>
</html>
