<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<body>
<table width="903" height="302" cellpadding="0" cellspacing="0">
    <tr>
    <td width="901" height="300" valign="top">&nbsp;</td>
	</tr>
</table>
<ul class="art-hmenu">
		<li>
			<a href="haladmin.php?top=home.php"><span class="l"></span><span class="r"></span><span class="t">HOME</span></a>
		</li>	
		<li>
			<a href="haladmin.php?top=penyakit_solusi.php"><span class="l"></span><span class="r"></span><span class="t">PENYAKIT & SOLUSI </span></a>
		</li>	
		<li>
			<a href="haladmin.php?top=gejala.php" ><span class="l"></span><span class="r"></span><span class="t">GEJALA</span></a>
		</li>	
		<li>
			<a href="haladmin.php?top=relasi.php"><span class="l"></span><span class="r"></span><span class="t">RELASI</span></a>
		</li>	
		<li>
			<a href="haladmin.php?top=lapgejala.php"><span class="l"></span><span class="r"></span><span class="t">LAPORAN GEJALA</span></a>
		</li>
        <li>
			<a href="haladmin.php?top=lapuser.php"><span class="l"></span><span class="r"></span><span class="t">LAPORAN PENDIAGNOSA</span></a>
		</li>		
		<li>
			<a href="logout.php"><span class="l"></span><span class="r"></span><span class="t">LOGOUT</span></a>
		</li>	
</ul>
</body>
</html>
