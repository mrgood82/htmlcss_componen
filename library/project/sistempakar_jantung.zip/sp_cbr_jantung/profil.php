<div class="art-post">
<div class="art-post-body">
<div class="art-post-inner art-article">
<h2 class="art-postheader">Profil</h2>
<div class="art-postcontent">
<table width="100%" border="0" align="center">
  <tr>
    <td width="200" rowspan="6" bordercolor="#FF00FF" bgcolor="#FFFFFF"><img src="images/fotoprofil.jpg" width="200" height="200" border="0"></td>
    <td width="136" height="29"><span class="style7 style13">Nama</span></td>
    <td width="8"><span class="style13"><strong>:</strong></span></td>
    <td width="235"><span class="style7 style13"></span></td>
  </tr>
  <tr>
    <td height="28"><span class="style7 style13">NIM</span></td>
    <td><span class="style13"><strong>:</strong></span></td>
    <td><span class="style7 style13"></span></td>
  </tr>
  <tr>
    <td height="29"><span class="style7 style13">Prodi</span></td>
    <td><span class="style13"><strong>:</strong></span></td>
    <td><span class="style7 style13">Teknik Informatika </span></td>
  </tr>
  <tr>
    <td height="29"><span class="style7 style13">Tempat/Tgl Lahir </span></td>
    <td><span class="style13"><strong>:</strong></span></td>
    <td><span class="style7 style13"> </span></td>
  </tr>
  <tr>
    <td height="28"><span class="style7 style13">Alamat</span></td>
    <td><span class="style13"><strong>:</strong></span></td>
    <td><span class="style7 style13"></span></td>
  </tr>
</table>
</div>
<div class="cleared"></div>
</div>
		<div class="cleared"></div>
    </div>
</div>