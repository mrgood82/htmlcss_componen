<div class="art-post">
<div class="art-post-body">
<div class="art-post-inner art-article">
<h2 class="art-postheader">Selamat datang pasien</h2><hr>
<div class="art-postcontent">
<p style="color:blue;  text-align: justify;"><img src="images/post-jantung.png" width="117" height="103" style="float:left;" /><strong>Sistem pakar diagnosa penyakit jantung dapat anda gunakan untuk mendiagnosa penyebab-penyebab penyakit jantung secara dini dan anda juga dapat mengenal jenis penyakit jantung diantaranya seperti jantung koroner dan sebagainya. Untuk memulai proses diagnosa penyakit silahkan klik link Mulai Diagnosa pada kotak dibawah ini </strong></p>

<p style="text-align: justify;"><img src="images/jantung2.jpg" width="117" height="103" style="float:left;" /><strong><u>Aterosklerosis</u></strong> diakibatkan oleh dinding arteri yang mengalami penebalan karena lemak, kolesterol dan buangan sel lainnya yang mengendap sehingga pasokan darah ke sel-sel otot mengalami penghambatan. Ateroskleroris bisa terjadi di seluruh bagian tubuh. Nah, bila terjadi pada dinding jantung maka akan disebut sebagai penyakit koroner atau penyakit jantung iskemik. Penyakit ini berlangsung menahun dan timbul banyak gangguan penyakit.<br />
</p>

<p style="text-align: justify;"><img src="images/jantung3.jpg" width="117" height="103" style="float:left;" /><strong><u>Infark Miokard</u></strong> adalah merupakan penyakit kematian otot jantung yang disebabkan oleh penyumbatan yang terjadi pada arteri koroner. Otot-otot jantung pun akan tidak tersuplai darah sehingga mengalami kerusakan dan bahkan kematian.<br />
  <br />
</p>
<p style="text-align: justify;"><img src="images/jatung4.jpg" width="117" height="103" style="float:left;" /><strong><u>Katup jantung</u> </strong> ini memiliki fungsi untuk mengendalikan aliran darah yang terjadi didalam jantung. dan kalau katup jantung mengalami kelainan, hal ini akan mengakibatkan terganggunya aliran darah tersebut, yakni pengecilan, kebocoran, atau tidak sempurnanya menutup. Kelainan katup jantung ini bisa merupakan bawaan dari sejak lahir ataupun karena efek samping pengobatan yang telah dilakukan.</p>

<p style="text-align: justify;"><strong><u>Gagal Jantung Kongestif</u></strong>
  Gagal jantung merupakan jantung yang tidak mampu lagi memompa darah ke seluruh tubuh secara efektif. Dikatakan gagal bukan karena jantung berhenti bekerja tetapi juga karena jantung tidak bisa memompa sekuat biasanya. Akibatnya darah bisa masuk ke paru-paru atau bagian tubuh lainnya.<br />
  <br />
</p>
<div style=" position:absolute; background-color:#DCD0AD; top:300px; left:50px; border:1px solid #999; border-radius:20px 20px; width:100px; height:50px; margin-top:-35px; text-align:center; padding:10px;"><a href="index.php?top=pasien_add_fm.php" class="active"><span class="l"></span><span class="r"></span><span class="t"><strong><br>Mulai Diagnosa</strong></span></a></div>
<p><a href="index.php?top=pasien_add_fm.php" class="active"><span class="l"></span><span class="r"></span></a></p>
</div>
<div class="cleared"></div>
</div>
		<div class="cleared"></div>
    </div>
</div>