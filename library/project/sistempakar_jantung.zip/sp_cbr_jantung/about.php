<div class="art-post">
<div class="art-post-body">
<div class="art-post-inner art-article">
<h2 class="art-postheader">Tentang programs</h2><hr>
<div class="art-postcontent">
<p>Program ini dirancang oleh : </p>
<div class="CSSTableGenerator">
<table width="100%" border="0" align="center">
  <tr>
    <td width="200" rowspan="6" bordercolor="#FF00FF" bgcolor="#FFFFFF"><img src="images/jantung.jpg" width="140" height="140" border="0"></td>
    <td width="136" height="29"><span class="style7 style13">Nama</span></td>
    <td width="8"><span class="style13"><strong>:</strong></span></td>
    <td width="235"><span class="style7 style13">?</span></td>
  </tr>
  <tr>
    <td height="28"><span class="style7 style13">NIM</span></td>
    <td><span class="style13"><strong><center>:</center></strong></span></td>
    <td><strong>?</strong></td>
  </tr>
  <tr>
    <td height="29"><span class="style7 style13">Prodi</span></td>
    <td><span class="style13"><strong><center>:</center></strong></span></td>
    <td><span class="style7 style13">?</span></td>
  </tr>

  <tr>
    <td height="29"><span class="style7 style13">Kampus</span></td>
    <td><span class="style13"><strong><center>:</center></strong></span></td>
    <td><span class="style7 style13">?</span></td>
  </tr>
  <tr>
    <td height="28"><span class="style7 style13">Alamat / email</span></td>
    <td><span class="style13"><strong> <center>:</center></strong></span></td>
    <td>?</td>
  </tr>
</table>
</div>
</div>
<div class="cleared"></div>
</div>
		<div class="cleared"></div>
    </div>
</div>