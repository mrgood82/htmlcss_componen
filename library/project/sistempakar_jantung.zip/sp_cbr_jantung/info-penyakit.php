<div class="art-post">
<div class="art-post-body">
<div class="art-post-inner art-article">
<h2 class="art-postheader">Informasi penyakit jantung</h2><hr>
<p style="text-align: justify;"><img src="images/jantung3.jpg" width="182" height="274" style="float:left;" />Penyakit jantung adalah istilah umum yang dikaitkan  dengan gangguan fungsi jantung dan tidak termasuk pada gangguan pembuluh darah  yang menyebabkan penyakit jantung. Banyak orang mengistilahkan penyakit jantung  ini adalah penyakit Kardiovaskuler.
Letak perbedaannya disini adalah jika penyakit  kardiovaskular mengacu pada gangguan pembuluh darah dan jantung, sedangkan  penyakit jantung hanya mengacu pada jantung saja.Menurut data dari WHO (World  Health Organization), penyakit jantung adalah penyakit pembunuh nomor satu di  berbagai negara termasuk Indonesia , Inggris, Australia, Kanada, AS, dan pada beberapa  negara lainnya.Penyakit jantung sendiri sangat banyak jenisnya, dan untuk  mengetahui jenis-jenis penyakit jantung ini mungkin tak ada salahnya untuk  mengikuti pembahansan singkat mengenai penyakit jantung</p>
<p>Jenis-jenis  penyakit jantung antara lain sebagai berikut :</p>

 <b> 1. Angina</b>

<p style="text-align: justify;">Angina  atau yang dikenal dengan angina pectoris adalah kerusakan otot jantung karena  kurangnya pasokan oksigen. Gejalanya bisa dirasakan seperti ketidaknyamanan  didada, sesak ataupun sakit. Angina ini bukan penyakit teknis melainkan gejala  dari penyakit arteri koroner. Kurangnya oksigen ke otot jantung ini biasanya  disebabkan oleh penyempitan pembuluh darah koroner karena akumulasi plak  (aterosklerosis).</p>

 <b> 2. Aritmia ( detak jantung yang tidak  teratur)</b>

<p style="text-align: justify;">Aritmia  masalah yang dikaitkan dengan irama jantung. Aritmia ini terjadi ketika impuls  listrik jantung yang mengkoordinasikan detak jantung tidak bekerja dengan baik,  membuat detak jantung dengan cara yang tidak seharusnya ( terlalu cepat, lambat  atau tidak teratur). </p>

 <b> 3. Penyakit jantung bawaan</b>

<p style="text-align: justify;">Penyakit jantung bawaan ini dikaitkan pada bayi yang baru  lahir namun telah mengalami gangguan pada kinerja jantung. Beberapa contoh  penyakit jantung bawaan termasuk:<br />
  Septal cacat ( adanya lubang antara dua bilik jantung).  Kondisi ini terkadang disebut dengan istilah jantung berlubang.Cacat Obstruksi  ( terjadi ketika aliran darah melewati berbagai bilik jantung )Penyakit jantung  sianotik ( penyakit jantung bawaan dimana kurangnya oksigen didalam darah untuk  dialirkan keseluruh tubuh karena adanya kerusakan di dalam hati.</p>

 <b> 4. Penyakit jantung arteri koroner</b>

<p style="text-align: justify;">Penyakit arteri koroner ini adalah kerusakan yang terjadi  pada jantung karena gangguan pada arteri koroner yang fungsinya untuk menyuplai  nutrisi, oksigen dan darah pada jantung. Faktor penyebabnya karena endapan plak  (endapan kolesterol). Akumulasi plak ini akan mempersempit arteri koroner  sehingga jantung kurang mendapatkan oksigen.</p>

  <b>5. Cardiomyopathy yang membesar</b>

<p style="text-align: justify;">Jenis penyakit jantung yang satu ini merupakan gangguan pada  bilik jantung yang melebar sehingga menyebabkan otot jantung menjadi lemah dan  tidak dapat memompa darah dengan baik. Alasan yang paling umum adalah kurangnya  pasokan oksigen yang mencapai otot jantung (iskemia) karena penyakit arteri  koroner. Biasanya mempengaruhi pula ventrikel kiri pada jantung kita.</p>

  <b>6. Infark miokard</b>

<p style="text-align: justify;">Infark  miokard ini juga dikenal dengan serangan jantung, infark jantung dan trombosis  koroner. Gangguan pada aliran darah (kekurangan oksigen) sehingga merusak atau  menghancurkan bagian dari otot jantung. Hal ini biasanya disebabkan oleh  gumpalan darah yang menggumpal di salah satu arteri koroner (pembuluh darah  yang mensuplai darah ke jantung. Hal ini juga dapat terjadi jika arteri  menyempit secara tiba-tiba (kejang).</p>

  <b>7. Gagal jantung</b>

<p style="text-align: justify;">Gagal  jantung yang juga dikenal dengan istilah gagal jantung kongestif. Gagal jantung  ini ditandai dengan kurang efisiennya jantung dalam memompa darah ke seluruh  tubuh sehingga terkadang salah satu bagian sisi tubuh akan terpengaruh dan bisa  juga dapat mempengaruhi sisi kanan dan kiri tubuh kita.</p>
<div class="art-postcontent">
  
</div>
                <div class="cleared"></div>
                </div>

		<div class="cleared"></div>
    </div>
</div>