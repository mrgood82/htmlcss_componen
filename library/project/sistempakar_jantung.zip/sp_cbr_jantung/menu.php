<ul class="art-hmenu">
		<li>
			<a href="index.php?top=home.php"><span class="l"></span><span class="r"></span><span class="t">HOME</span></a>
		</li>	
		<li>
			<a href="index.php?top=pasien_add_fm.php" class="active"><span class="l"></span><span class="r"></span><span class="t">PROSES DIAGNOSA</span></a>
		</li>	
        <li>
			<a href="index.php?top=info-penyakit.php"><span class="l"></span><span class="r"></span><span class="t">INFORMASI</span></a>
		</li>
        <li>
			<a href="index.php?top=about.php"><span class="l"></span><span class="r"></span><span class="t">TENTANG</span></a>
		</li>
		<li>
			<a href="index.php?top=daftar-penyakit.php"><span class="l"></span><span class="r"></span><span class="t">DAFTAR PENYAKIT</span></a>
		</li>		
		<li>
			<a target="_blank" href="admin/index.php"><span class="l"></span><span class="r"></span><span class="t">LOGIN</span></a>
		</li>	
	</ul>