## AlQuran Online 

sebuah program dengan nama AlQuran Online yang dibuat dengan bahasa pemrograman javascript. semua data yang saya tampilkan saya dapatkan dari sebuah API.

### dibuat dengan berikut

* HTML
* CSS 
  * [Bootstrap](https://getbootstrap.com)
* Javascriot

### lainnya 

* [API](https://quran-api.santrikoding.com/)
* handphone
* code editor (Acode)
* edit gambar (Pixellab)

### preview

![image1](https://github.com/candradwicahyo/AlQuran-online/blob/master/image1.jpg)

![image2](https://github.com/candradwicahyo/AlQuran-online/blob/master/image2.jpg)

[tekan link ini untuk mencoba program ini](https://candradwicahyo.github.io/AlQuran-online)

> dibuat oleh **candra dwi cahyo**