<?php
include('config.php');

//tangkap data dari form
$kd_jadwal = $_POST['kd_jadwal'];
$hari = $_POST['hari'];
$jam_awal = $_POST['jam_awal'];
$jam_akhir = $_POST['jam_akhir'];
$keterangan = $_POST['keterangan'];

//update data di database sesuai kd_jadwal
$query = mysql_query("update jadwal set kd_jadwal ='$kd_jadwal', hari='$hari', jam_awal='$jam_awal', jam_akhir='$jam_akhir', keterangan='$keterangan' where kd_jadwal='$kd_jadwal'") or die(mysql_error());

if ($query) {
	header('location:jadwal.php?msg=success');
} else {
	header('location:jadwal.php?msg=failed');
}
?>