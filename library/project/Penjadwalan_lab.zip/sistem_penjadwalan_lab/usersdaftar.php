<?php
session_start();

$logged_in = false;

//jika session username belum dibuat, atau session username kosong
if (isset($_SESSION['username']) || !empty($_SESSION['username'])) {
	$logged_in = true;
}

include_once('config.php');
?>

<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Daftar</title>
<link rel="stylesheet" href="css/style.css" type="text/css" />
<link rel="stylesheet" href="materialize/css/materialize.css" type="text/css" />
<link rel="stylesheet" href="materialize/css/materialize.min.css" type="text/css" />
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<script src="materialize/js/jquery-1.11.3.min.js"></script>
</head>

<body>
<div style="margin:auto; padding:25px 0 30px; text-align:center">
	<h2 style="color:26a69a"><strong>Sistem Penjadwalan Lab</strong></h2>
</div>
<div style="margin:auto">
	<form action="usersinsert.php" method="post" style="width:400px; margin:auto;">
		<fieldset>
			<legend>Daftar</legend>
			
			<?php
			error_reporting(E_ALL ^ (E_NOTICE | E_WARNING)); 			
			$message = $_GET['msg'];
			if ($message == 'success') {
			?>
			<div class="info">Success</div>
			<?php } else if ($message == 'failed') {?>
			<div class="error">Error</div>
			<?php } ?>
			
			<div class="input-field col s6">
      		<i class="material-icons prefix">account_circle</i>
          <input id="icon_prefix" type="text" class="validate" name="username" required>
          <label for="icon_prefix">Username</label>
    </div>
			<div class="input-field col s6">
      		<i class="material-icons prefix">lock</i>
          <input id="icon_prefix" type="password" class="validate" name="password" required>
          <label for="icon_prefix">Password</label>
    </div>	

    <div class="input-field col s6">
      		<i class="material-icons prefix">verified_user</i>
          <input id="icon_prefix" type="email" class="validate" name="email" required>
          <label for="icon_prefix">Email</label>
    </div>
			<div class="input-field col s6">
      		<i class="material-icons prefix">perm_identity</i>
          <input id="icon_prefix" type="text" class="validate" name="fullname" required>
          <label for="icon_prefix">Full Name</label>
    </div>	

    		<div class="row center">
        <button class="btn waves-effect waves-light" type="submit" name="submit">Daftar<i class="material-icons right">send</i></button> 
        <button class="btn waves-effect waves-light" type="button" Value="Home Page" Onclick="window.location.href='login.php'">Masuk<i class="material-icons right">subject</i></button>
      </div>

		</fieldset>
	</form>
<br>
	<div class="row center">
Copyright 2020
    </div>
  </div>
</div>
<script src="materialize/js/materialize.min.js"></script>
</body>
</html>