<?php 
include_once('config.php');

// terima data dari halaman daftar.php
$kd_jadwal  = mysql_real_escape_string($_POST['kd_jadwal']);
$hari   = mysql_real_escape_string($_POST['hari']);
$jam_awal    = mysql_real_escape_string($_POST['jam_awal']);
$jam_akhir    = mysql_real_escape_string($_POST['jam_akhir']);
$keterangan    = mysql_real_escape_string($_POST['keterangan']);

// simpan data ke database
$query = mysql_query("insert into jadwal values('$kd_jadwal', '$hari', '$jam_awal', '$jam_akhir', '$keterangan')");

if ($query) {
  // jika berhasil menyimpan
  header('location: jadwal.php?msg=success');
} else {
  // jika gagal menyimpan
  header('location: jadwaltambah.php?msg=failed');
}
?>