<?php 
include_once('config.php');
include('cek-login.php');
?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>
<?php
	$username = $_SESSION['username'];
	$query_user_login = mysql_query("select * from users where username='$username'");
	
	$user_login = mysql_fetch_array($query_user_login);
	?>

Hi <?php echo $user_login['role']; ?>! - Sistem Penjadwalan LAB </title>
<link rel="stylesheet" href="css/style.css" type="text/css" />
<link rel="stylesheet" href="materialize/css/materialize.css" type="text/css" />
<link rel="stylesheet" href="materialize/css/materialize.min.css" type="text/css" />
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<script src="materialize/js/jquery-1.11.3.min.js"></script>
<style type="text/css">
	th,td {
		text-align:center;
	}
</style>
</head>

<body>
<div style="margin:auto; padding:50px 0 30px; text-align:center">
	<h2 style="color:#26a69a">Sistem Penjadwalan Lab</h2>
</div>
<div style="margin:auto">
	<div class="content z-depth-4">
	
	<?php
	error_reporting(E_ALL ^ (E_NOTICE | E_WARNING)); 	
	$message = $_GET['msg'];
	
	if ($message == 'success') {
	?>
	<div class="info">Success</div>
	<?php } else if ($message == 'failed') {?>
	<div class="error">Error</div>
	<?php } ?>
	<div>
	<?php
	$username = $_SESSION['username'];
	$query_user_login = mysql_query("select * from users where username='$username'");
	
	$user_login = mysql_fetch_array($query_user_login);
	?>
	<span class="btn waves-effect waves-light red darken-2" style="cursor:default">Selamat Datang, <?php echo $user_login['fullname']; ?>!</span>
	 <button class="btn waves-effect waves-light red darken-2 right" type="button" Value="logout" Onclick="window.location.href='logout.php'">Logout <i class="material-icons right">exit_to_app</i></button>
      </div>
	<br /><br/>
			<div>
			<select class="browser-default" onChange="window.location.href=this.value">
			<option value="index.php?hari=senin">Pilih Hari</option>
				<option value="index.php?hari=senin">Senin</option>
				<option value="index.php?hari=selasa">Selasa</option>
				<option value="index.php?hari=rabu">Rabu</option>
				<option value="index.php?hari=kamis">Kamis</option>
				<option value="index.php?hari=jumat">Jum'at</option>
			</select>
		</div>
		<br><br>
		<?php
	error_reporting(E_ALL ^ (E_NOTICE | E_WARNING)); 	
	$jadwal = $_GET['hari'];
	
	if ($jadwal == 'senin') {
	?>
		<table  class="highlight responsive-table bordered z-depth-4">
		<thead>
			<tr>
				<th>No</th>
				<th>Mata Kuliah</th>
				<th>Dosen</th>
				<th>Kel</th>
				<th>Ruang</th>
				<th>Mulai</th>
				<th>Selesai</th>
				<th>Keterangan</th>
			</tr>
		</thead>
		<tbody>
		<?php 
		$query = mysql_query("SELECT * FROM dosen JOIN mata_kuliah ON dosen.nip = mata_kuliah.nip
								JOIN gunakan ON gunakan.kd_matakuliah = mata_kuliah.kd_matakuliah
								JOIN ruang_lab ON gunakan.id_lab = ruang_lab.id_lab
								JOIN jadwal ON jadwal.kelompok = gunakan.kelompok where hari='Senin'");
			
			$i = 1;
			
			while ($data = mysql_fetch_array($query)) {
			?>
			<tr class="<?php if ($i % 2 == 0) { echo "odd"; } else { echo "even"; } ?>">
				<td><?php echo $i; ?></td>
				<td><?php echo $data['nama_matakuliah']; ?></td>
				<td><?php echo $data['nama_dosen']; ?></td>
				<td><?php echo $data['kelompok']; ?></td>
				<td><?php echo $data['nama_lab']; ?></td>
				<td><?php echo $data['jam_awal']; ?></td>
				<td><?php echo $data['jam_akhir']; ?></td>
				<td><?php echo $data['keterangan']; ?></td>
			</tr>
			<?php 
				$i++;
			} 
			?>
		</tbody>
	</table>
	<?php } else if ($jadwal == 'selasa') {?>
			<table  class="highlight responsive-table bordered z-depth-4">
		<thead>
			<tr>
				<th>No</th>
				<th>Mata Kuliah</th>
				<th>Dosen</th>
				<th>Kel</th>
				<th>Ruang</th>
				<th>Mulai</th>
				<th>Selesai</th>
				<th>Keterangan</th>
			</tr>
		</thead>
		<tbody>
		<?php 
		$query = mysql_query("SELECT * FROM dosen JOIN mata_kuliah ON dosen.nip = mata_kuliah.nip
								JOIN gunakan ON gunakan.kd_matakuliah = mata_kuliah.kd_matakuliah
								JOIN ruang_lab ON gunakan.id_lab = ruang_lab.id_lab
								JOIN jadwal ON jadwal.kelompok = gunakan.kelompok where hari='Selasa'");
			
			$i = 1;
			
			while ($data = mysql_fetch_array($query)) {
			?>
			<tr class="<?php if ($i % 2 == 0) { echo "odd"; } else { echo "even"; } ?>">
				<td><?php echo $i; ?></td>
				<td><?php echo $data['nama_matakuliah']; ?></td>
				<td><?php echo $data['nama_dosen']; ?></td>
				<td><?php echo $data['kelompok']; ?></td>
				<td><?php echo $data['nama_lab']; ?></td>
				<td><?php echo $data['jam_awal']; ?></td>
				<td><?php echo $data['jam_akhir']; ?></td>
				<td><?php echo $data['keterangan']; ?></td>
			</tr>
			<?php 
				$i++;
			} 
			?>
		</tbody>
	</table>
	<?php } else if ($jadwal == 'rabu') {?>
			<table  class="highlight responsive-table bordered z-depth-4">
		<thead>
			<tr>
				<th>No</th>
				<th>Mata Kuliah</th>
				<th>Dosen</th>
				<th>Kel</th>
				<th>Ruang</th>
				<th>Mulai</th>
				<th>Selesai</th>
				<th>Keterangan</th>
			</tr>
		</thead>
		<tbody>
		<?php 
		$query = mysql_query("SELECT * FROM dosen JOIN mata_kuliah ON dosen.nip = mata_kuliah.nip
								JOIN gunakan ON gunakan.kd_matakuliah = mata_kuliah.kd_matakuliah
								JOIN ruang_lab ON gunakan.id_lab = ruang_lab.id_lab
								JOIN jadwal ON jadwal.kelompok = gunakan.kelompok where hari='Rabu'");
			
			$i = 1;
			
			while ($data = mysql_fetch_array($query)) {
			?>
			<tr class="<?php if ($i % 2 == 0) { echo "odd"; } else { echo "even"; } ?>">
				<td><?php echo $i; ?></td>
				<td><?php echo $data['nama_matakuliah']; ?></td>
				<td><?php echo $data['nama_dosen']; ?></td>
				<td><?php echo $data['kelompok']; ?></td>
				<td><?php echo $data['nama_lab']; ?></td>
				<td><?php echo $data['jam_awal']; ?></td>
				<td><?php echo $data['jam_akhir']; ?></td>
				<td><?php echo $data['keterangan']; ?></td>
			</tr>
			<?php 
				$i++;
			} 
			?>
		</tbody>
	</table>
	
	<?php } else if ($jadwal == 'kamis') {?>
			<table  class="highlight responsive-table bordered z-depth-4">
		<thead>
			<tr>
				<th>No</th>
				<th>Mata Kuliah</th>
				<th>Dosen</th>
				<th>Kel</th>
				<th>Ruang</th>
				<th>Mulai</th>
				<th>Selesai</th>
				<th>Keterangan</th>
			</tr>
		</thead>
		<tbody>
		<?php 
		$query = mysql_query("SELECT * FROM dosen JOIN mata_kuliah ON dosen.nip = mata_kuliah.nip
								JOIN gunakan ON gunakan.kd_matakuliah = mata_kuliah.kd_matakuliah
								JOIN ruang_lab ON gunakan.id_lab = ruang_lab.id_lab
								JOIN jadwal ON jadwal.kelompok = gunakan.kelompok where hari='Kamis'");
			
			$i = 1;
			
			while ($data = mysql_fetch_array($query)) {
			?>
			<tr class="<?php if ($i % 2 == 0) { echo "odd"; } else { echo "even"; } ?>">
				<td><?php echo $i; ?></td>
				<td><?php echo $data['nama_matakuliah']; ?></td>
				<td><?php echo $data['nama_dosen']; ?></td>
				<td><?php echo $data['kelompok']; ?></td>
				<td><?php echo $data['nama_lab']; ?></td>
				<td><?php echo $data['jam_awal']; ?></td>
				<td><?php echo $data['jam_akhir']; ?></td>
				<td><?php echo $data['keterangan']; ?></td>
			</tr>
			<?php 
				$i++;
			} 
			?>
		</tbody>
	</table>
	
	<?php } else if ($jadwal == 'jumat') {?>
			<table  class="highlight responsive-table bordered z-depth-4">
		<thead>
			<tr>
				<th>No</th>
				<th>Mata Kuliah</th>
				<th>Dosen</th>
				<th>Kel</th>
				<th>Ruang</th>
				<th>Mulai</th>
				<th>Selesai</th>
				<th>Keterangan</th>
			</tr>
		</thead>
		<tbody>
		<?php 
		$query = mysql_query("SELECT * FROM dosen JOIN mata_kuliah ON dosen.nip = mata_kuliah.nip
								JOIN gunakan ON gunakan.kd_matakuliah = mata_kuliah.kd_matakuliah
								JOIN ruang_lab ON gunakan.id_lab = ruang_lab.id_lab
								JOIN jadwal ON jadwal.kelompok = gunakan.kelompok where hari='Jum'at'");
			
			$i = 1;
			
			while ($data = mysql_fetch_array($query)) {
			?>
			<tr class="<?php if ($i % 2 == 0) { echo "odd"; } else { echo "even"; } ?>">
				<td><?php echo $i; ?></td>
				<td><?php echo $data['nama_matakuliah']; ?></td>
				<td><?php echo $data['nama_dosen']; ?></td>
				<td><?php echo $data['kelompok']; ?></td>
				<td><?php echo $data['nama_lab']; ?></td>
				<td><?php echo $data['jam_awal']; ?></td>
				<td><?php echo $data['jam_akhir']; ?></td>
				<td><?php echo $data['keterangan']; ?></td>
			</tr>
			<?php 
				$i++;
			} 
			?>
		</tbody>
	</table>
	
	<?php } ?>
	<div>
	<?php
	$username = $_SESSION['username'];
	$query_user_login = mysql_query("select * from users where username='$username'");
	
	$user_login = mysql_fetch_array($query_user_login);
	?>
<br>
<div class="row center">
<?php 
if ($_SESSION['role'] == 'admin') {
					?>
					<button class="btn waves-effect red darken-2" type="button" Value="Dashboard" Onclick="window.location.href='dashboard.php'">Dashboard</button>
						<?php if ($data['username'] != 'admin') {?>
						<?php } ?>
					
					<?php } ?>
</div>
	</div>
</div><br>
	<div class="row center">
<span style="color:#26a69a">Copyright 2020</span>
    </div>
<div class="clear"></div>
<div style="padding-bottom:50px;"></div>
</body>
</html>