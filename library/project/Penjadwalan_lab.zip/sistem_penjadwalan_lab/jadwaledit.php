<?php
$logged_in = false;

//jika session username belum dibuat, atau session username kosong
if (isset($_SESSION['username']) || !empty($_SESSION['username'])) {
	$logged_in = true;
}

include_once('config.php');
include('cek-login.php');


if ($_SESSION['role']=='admin'){
}
else {?><script type="text/javascript">
            window.location.href = "index.php"
    </script> 
	<h1>anda tidak berhak mengakses halamman ini</h1>
<?php }

?>

<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Edit Jadwal</title>
<link rel="stylesheet" href="css/style.css" type="text/css" />
<link rel="stylesheet" href="materialize/css/materialize.css" type="text/css" />
<link rel="stylesheet" href="materialize/css/materialize.min.css" type="text/css" />
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<script src="materialize/js/jquery-1.11.3.min.js"></script>
</head>

<body>
<div style="margin:auto; padding:50px 0 30px; text-align:center">
	<h2 style="color:26a69a">Sistem Penjadwalan Lab</h2>
</div>
<div style="margin:auto">
	<form action="jadwalupdate.php" method="post" style="width:400px; margin:auto;">
		<fieldset>
			<legend>Update Jadwal</legend>
			
			<?php
			error_reporting(E_ALL ^ (E_NOTICE | E_WARNING)); 			
			$message = $_GET['msg'];
			if ($message == 'success') {
			?>
			<div class="info">Success</div>
			<?php } else if ($message == 'failed') {?>
			<div class="error">Error</div>
			<?php } ?>
			

    <?php 
      // terima nip dari halaman dosen
      $kdjadwal = $_GET['kdjadwal'];
      
      $query = mysql_query("select * from jadwal where kd_jadwal ='$kdjadwal'");
      
      $data = mysql_fetch_array($query);
      ?>

						<div class="input-field col s6">
      		<i class="material-icons prefix">vpn_key</i>
          <input id="icon_prefix" type="text" class="validate" name="kd_jadwal" required value="<?php echo $data['kd_jadwal']; ?>" disabled>
		  <label for="icon_prefix">Kode Jadwal</label>
    </div>	

    <div class="input-field col s6">
      		<i class="material-icons prefix">hourglass_empty</i>
       <input id="icon_prefix" type="time" class="validate" name="jam_awal" required value="<?php echo $data['jam_awal']; ?>">    
    </div>
	
	<div class="input-field col s6">
      		<i class="material-icons prefix">hourglass_full</i>
       <input id="icon_prefix" type="time" class="validate" name="jam_akhir" required value="<?php echo $data['jam_akhir']; ?>">    
    </div>
				<div class="input-field col s6">
			<div class="input-field col s6">
			<select class="browser-default" name="hari">
      <option value="Senin">Senin</option>
      <option value="Selasa">Selasa</option>
	  <option value="Rabu">Rabu</option>
	  <option value="Kamis">Kamis</option>
	  <option value="Jum'at">Jum'at</option>
	  <option value="Sabtu">Sabtu</option>
    </select>
    </div>	
    </div>
	
	Keterangan : 
      <input name="keterangan" type="radio" value="Hadir" id="hadir" /><label for="hadir">Hadir</label>
      <input name="keterangan" type="radio" value="Tidak Hadir" id="tidakhadir" /><label for="tidakhadir">Tidak Hadir</label>
	<br>

    		<div class="row center">
        <button class="btn waves-effect waves-light" type="submit" name="submit">Update Jadwal<i class="material-icons right">send</i></button> 
      </div>
<input type="hidden" name="kd_jadwal" value="<?php echo $data['kd_jadwal']; ?>" />
		</fieldset>
	</form>
<br>
	<div class="row center">
Copyright 2020
    </div>
  </div>
</div>
<script src="materialize/js/materialize.min.js"></script>
</body>
</html>