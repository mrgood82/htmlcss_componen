        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Dashboard</h1>
                    </div>
                    <!-- /.col-lg-12 -->
                    <div class="col-sm-12">
                        <div class="alert alert-info" role="alert">
                            SELAMAT DATANG DI HALAMAN ADMINISTRATOR
                        </div>
                        <?php echo $this->session->flashdata('pesan') ?>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>