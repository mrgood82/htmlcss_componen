			<?php $this->load->view('main/v_sidebar') ?>

			<div class="col-sm-8 content">

				<div class="panel panel-default welcome">
				  	<!-- <div class="panel-heading"><i class="glyphicon glyphicon-list-alt"></i> Profile Sekolah</div> -->
				  	<div class="panel-body">
				    	<?php echo $profile['isi_halaman'] ?>
				  	</div>
				</div>
			</div><!-- content -->