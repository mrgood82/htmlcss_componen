{
	"title": "tinymce",
	"tests": [
		{"title": "Gecko caret", "url": "gecko_caret.html", "manual": true},
		{"title": "Noneditable", "url": "noneditable.html", "manual": true},
		{"title": "Removeformat", "url": "removeformat.html", "manual": true},
		{"title": "Resize", "url": "resize.html", "manual": true},
		{"title": "Visual blocks", "url": "visualblocks.html", "manual": true},
		{"title": "Custom theme", "url": "custom_theme.html", "manual": true},
		{"title": "Development", "url": "development.html", "manual": true},
		{"title": "Classic theme", "url": "classic.html", "manual": true},
		{"title": "Inline editing", "url": "inline.html", "manual": true}
	]
}
