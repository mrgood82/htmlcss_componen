<?php
class Excelreaders {
 
    function __construct() {
		//FpdfLibrary
        include_once APPPATH . '/third_party/spreadsheet-reader/php-excel-reader/excel_reader2.php';
    }
}
?>
