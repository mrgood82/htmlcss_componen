<<br/><br/>
<div style="margin-left: auto; margin-right: auto; width: 500px;">
	<div class="box">
		<div class="box-inner">
			<div class="box-header well">
				<h2>Logout</h2>
			</div>
			<div class="box-content">
				<h4>Terima kasih Telah melakukan Voting</h4>
				<p>Silahkan Logout dengan Menekan Tombol <b>Logout</b> Dibawah!</p>
				
				<center><a href="<?php echo base_url(); ?>index.php/user/logout"><button type="button" class="btn btn-primary text-center"><span class="glyphicon glyphicon-log-out"></span> Logout</button></a></center>
			</div>
		</div>
	</div>
</div>