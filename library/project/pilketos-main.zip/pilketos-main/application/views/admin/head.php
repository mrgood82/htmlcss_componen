<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>E-Pilketos | Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link id="bs-css" href="<?php echo base_url(); ?>asset/css/bootstrap-cerulean.min.css" rel="stylesheet">
    <link href='<?php echo base_url(); ?>asset/vendor/responsive-tables/responsive-tables.css' rel='stylesheet'>
    <link href='<?php echo base_url(); ?>asset/vendor/datatables/datatables.min.css' rel='stylesheet'>
    <link href='<?php echo base_url(); ?>asset/vendor/bootstrap-tour/build/css/bootstrap-tour.min.css' rel='stylesheet'>
    <link href="<?php echo base_url(); ?>asset/css/charisma-app.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>asset/css/main.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>asset/vendor/responsive-tables/responsive-tables.css" rel='stylesheet'>
</head>
