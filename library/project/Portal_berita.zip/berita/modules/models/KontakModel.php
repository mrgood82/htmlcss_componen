<?php

class KontakModel extends Model {

    protected $tableName = "kontak";
}
?>