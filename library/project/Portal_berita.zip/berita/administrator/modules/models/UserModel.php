<?php


class UserModel extends Model{

    protected $tableName = "user";

}
?>