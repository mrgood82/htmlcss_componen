<?php 

    $con = mysqli_connect('localhost','root','','sr_system');
    if(!$con)
    {
        echo ' Please Check Your Connection ';
    }


?>