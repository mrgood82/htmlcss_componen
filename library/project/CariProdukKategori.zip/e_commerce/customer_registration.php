<?php
if (isset($_GET["register"])) {
	
	?>

	<!DOCTYPE html>
	<html>
	<head>
		<meta charset="UTF-8">
		<title>Kumpulan Kode Store</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<script src="js/jquery2.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="main.js"></script>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>
		<div class="wait overlay">
			<div class="loader"></div>
		</div>
		<div class="navbar navbar-inverse navbar-fixed-top">
			<div class="container-fluid">	
				<div class="navbar-header">
					<a href="#" class="navbar-brand"><strong>KUMPULAN KODE STORE</strong></a>
				</div>
				<ul class="nav navbar-nav">
					<li><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
					<li><a href="index.php"><span class="glyphicon glyphicon-th"></span> Produk</a></li>
				</ul>
			</div>
		</div>
		<p><br/></p>
		<p><br/></p>
		<p><br/></p>
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-2"></div>
				<div class="col-md-8" id="signup_msg">
					<!--Alert from signup form-->
				</div>
				<div class="col-md-2"></div>
			</div>
			<div class="row">
				<div class="col-md-2"></div>
				<div class="col-md-8">
					<div class="panel panel-primary">
						<div class="panel-heading"><strong>Registrasi Customer</strong></div>
						<div class="panel-body">

							<form id="signup_form" onsubmit="return false">
								<div class="row">
									<div class="col-md-6">
										<label for="f_name">Nama depan</label>
										<input type="text" id="f_name" name="f_name" class="form-control">
									</div>
									<div class="col-md-6">
										<label for="f_name">Nama belakang</label>
										<input type="text" id="l_name" name="l_name" class="form-control">
									</div>
								</div><br>
								<div class="row">
									<div class="col-md-12">
										<label for="email">Email</label>
										<input type="text" id="email" name="email" class="form-control">
									</div>
								</div><br>
								<div class="row">
									<div class="col-md-12">
										<label for="password">Password</label>
										<input type="password" id="password" name="password" class="form-control">
									</div>
								</div><br>
								<div class="row">
									<div class="col-md-12">
										<label for="repassword">Re-enter password</label>
										<input type="password" id="repassword" name="repassword" class="form-control">
									</div>
								</div><br>
								<div class="row">
									<div class="col-md-12">
										<label for="mobile">No. Telepon/Hp</label>
										<input type="text" id="mobile" name="mobile" class="form-control">
									</div>
								</div><br>
								<div class="row">
									<div class="col-md-12">
										<label for="address1">Tempat tinggal saat ini</label>
										<input type="text" id="address1" name="address1" class="form-control">
									</div>
								</div><br>
								<div class="row">
									<div class="col-md-12">
										<label for="address2">Alamat lengkap tempat tinggal </label>
										<input type="text" id="address2" name="address2" class="form-control">
									</div>
								</div>
								<p><br/></p>
								<div class="row">
									<div class="col-md-12">
										<button type="submit" name="signup_button" class="btn btn-primary  pull-right"><strong>Registrasi</strong></button>

									</div>
								</div>

							</div>
						</form>

					</div>
				</div>
				<div class="col-md-2"></div>
			</div>
		</div>
	</body>
	</html>
	<?php
}



?>






















