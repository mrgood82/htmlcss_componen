<?php
session_start();
if(isset($_SESSION["uid"])){
	header("location:profile.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Kumpulan Kode Store</title>
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<script src="js/jquery2.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="main.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css">
	<style></style>
</head>
<body>
	<div class="wait overlay">
		<div class="loader"></div>
	</div>
	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">	
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
					<span class="sr-only">navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="#" class="navbar-brand"><strong>KUMPULAN KODE STORE</strong></a>
			</div>
			<div class="collapse navbar-collapse" id="collapse">
				<ul class="nav navbar-nav">
					<li><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
					<li><a href="index.php"><span class="glyphicon glyphicon-th"></span> Produk</a></li>
				</ul>
				<form class="navbar-form navbar-left">
					<div class="form-group">
						<input type="text" class="form-control" placeholder="Cari produk disini" id="search" style="width:300px;">
					</div>&nbsp;
					<button type="submit" class="btn btn-primary" id="search_btn"><span class="glyphicon glyphicon-search"></span></button>
				</form>
				<ul class="nav navbar-nav navbar-right">
					<li><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-shopping-cart"></span> Keranjang <span class="badge">0</span></a>
						<div class="dropdown-menu" style="width:490px; padding-top: 0px; border-radius: 0px; padding-bottom: 0px ">
							<div class="panel panel-primary" style="margin-bottom: 0px; border: 0px;">

								<div class="panel-body">
									<div class="row">
										<div class="col-md-3"><strong>No.</strong></div>
										<div class="col-md-3"><strong>Produk</strong></div>
										<div class="col-md-3"><strong>Nama Produk</strong></div>
										<div class="col-md-3"><strong>Harga Produk</strong></div>
									</div><hr>
									<div id="cart_product">
										<div class="row">
											<div class="col-md-3">Sl.No</div>
											<div class="col-md-3">Product Image</div>
											<div class="col-md-3">Product Name</div>
											<div class="col-md-3">Price in $.</div>
										</div>
									</div>
								</div>
							</div>

						</div>
					</li>
					<li><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-circle-arrow-right"></span> Login</a>
						<ul class="dropdown-menu" style="width:300px; padding-top: 0px; border-radius: 0px; padding-bottom: 0px ">
							<div style="width:300px; border-radius: 0px">
							<div class="panel panel-primary" style="margin-bottom: 0px; border-radius: 0px">
								<div class="panel-heading" style="border-radius: 0px">
									<h3 class="panel-title"><strong><center>SILAHKAN LOGIN</center></strong></h3>
								</div>
								<div class="panel-body">
									<form onsubmit="return false" id="login">
										
										<input type="email" class="form-control" name="email" id="email" placeholder="Masukan username/email" required/><br>
										
										<input type="password" class="form-control" name="password" id="password" placeholder="Masukan kata sandi" required/>
										<br>
										<button type="submit" class="btn btn-primary btn-sm pull-right"> <strong>Login</strong></button>
									</form>
								</div>

							</div>
						</div>
					</ul>
				</li>
			</ul>
		</div>
	</div>
</div>	
<p><br/></p>
<p><br/></p>
<p><br/></p>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-1"></div>
		<div class="col-md-2 col-xs-12">
			<div id="get_category">
			</div>
				<div id="get_brand">
				</div>
			</div>
			<div class="col-md-8 col-xs-12">
				<div class="row">
					<div class="col-md-12 col-xs-12" id="product_msg">
					</div>
				</div>
				<div class="panel panel-primary">
					<div class="panel-heading"><strong>Produk</strong></div>
					<div class="panel-body">
						<div id="get_product">
							
						</div>
						
					</div>
					<div class="panel-footer" style="text-align: right">&copy; 2020 <a href="facebook.com/kumpulankode">kumpulankode.com</a></div>
				</div>
			</div>
			<div class="col-md-1"></div>
		</div>
	</div>
</body>
</html>
















































