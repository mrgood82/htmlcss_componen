<?php

$servername = "localhost";
$username = "root";
$password = "";
$db = "e_commerce";

// Create connection
$con = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$con) {
    die("Connection gagal hubungi admin bale kode: " . mysqli_connect_error());
}


?>