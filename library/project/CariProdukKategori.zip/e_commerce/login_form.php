<?php
if (isset($_SESSION["uid"])) {
	header("location:profile.php");
}

if (isset($_POST["login_user_with_product"])) {
	
	$product_list = $_POST["product_id"];
	
	$json_e = json_encode($product_list);
	
	setcookie("product_list",$json_e,strtotime("+1 day"),"/","","",TRUE);

}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Kumpulan Kode Store</title>
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<script src="js/jquery2.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="main.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="wait overlay">
		<div class="loader"></div>
	</div>
	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">	
			<div class="navbar-header">
				<a href="#" class="navbar-brand"><strong>KUMPULAN KODE STORE</strong></a>
			</div>
			<ul class="nav navbar-nav">
				<li><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
				<li><a href="index.php"><span class="glyphicon glyphicon-th"></span> Produk</a></li>
			</ul>
		</div>
	</div>
	<p><br/></p>
	<p><br/></p>
	<p><br/></p>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8" id="signup_msg">
				
			</div>
			<div class="col-md-2"></div>
		</div>
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-4">
				<div class="panel panel-primary">
					<div class="panel-heading"><strong>Login Customer </strong> </div>
					<div class="panel-body">
						
						<form onsubmit="return false" id="login">
							
							<input type="email" class="form-control" name="email" id="email" placeholder="Masukan username/email" required/><br>
							
							<input type="password" class="form-control" name="password" id="password" placeholder="Masukan kata sandi" required/>
							<p><br/></p>
							<button type="submit" class="btn btn-primary" style="float:right;"><strong>Login</strong></button>

							
							
							<div><span class="glyphicon glyphicon-circle-arrow-right"></span> <a href="customer_registration.php?register=1">Buat akun</a></div>						
						</form><br><br>
						<div id="e_msg"></div>
					</div>

				</div>
			</div>
			<div class="col-md-4"></div>
		</div>
	</body>
	</html>






















