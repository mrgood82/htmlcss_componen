<?php

session_start();
if(!isset($_SESSION["uid"])){
	header("location:index.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>kumpulankode.com</title>
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<script src="js/jquery2.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="main.js"></script>
	<style>
	@media screen and (max-width:480px){
		#search{width:80%;}
		#search_btn{width:30%;float:right;margin-top:-32px;margin-right:10px;}
	}
</style>
</head>
<body>
	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">	
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
					<span class="sr-only"> navigation toggle</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="#" class="navbar-brand"><strong>KUMPULAN KODE STORE</strong></a>
			</div>
			<div class="collapse navbar-collapse" id="collapse">
				<ul class="nav navbar-nav">
					<li><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
					<li><a href="index.php"><span class="glyphicon glyphicon-th"></span> Produk</a></li>
					<li style="width:300px;left:10px;top:8px;"><input type="text" class="form-control" id="search" placeholder="Cari produk disini"></li>
					<li style="top:8px;left:18px;"><button class="btn btn-primary" id="search_btn"><span class="glyphicon glyphicon-search"></span></button></li>
				</ul>
				<ul class="nav navbar-nav navbar-right">
					<li><a href="#" id="cart_container" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-shopping-cart"></span> Keranjang <span class="badge">0</span></a>
						<div class="dropdown-menu" style="width:490px; padding-top: 0px; border-radius: 0px; padding-bottom: 0px ">

							<div class="panel panel-primary" style="margin-bottom: 0px; border: 0px;">

								<div class="panel-body">
									<div class="row">
										<div class="col-md-3"><strong>No.</strong></div>
										<div class="col-md-3"><strong>Produk</strong></div>
										<div class="col-md-3"><strong>Nama Produk</strong></div>
										<div class="col-md-3"><strong>Harga Produk</strong></div>
									</div><hr>
									<div id="cart_product">
										<div class="row">
											<div class="col-md-3">No.</div>
											<div class="col-md-3">Produk</div>
											<div class="col-md-3">Nama Produk</div>
											<div class="col-md-3">Harga Produk</div>
										</div>
									</div>
								</div>
							</div>

						</div>
					</li>
					<li class="active"><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span> <?php echo "Hai,".$_SESSION["name"]; ?></a>
						<ul class="dropdown-menu">
							<li><a href="cart.php"><span class="glyphicon glyphicon-shopping-cart"></span>  Keranjang</a></li>
							<li><a href="customer_order.php"><span class="glyphicon glyphicon-shopping-cart"></span> Orders</a></li>
							<li><a href=""><span class="glyphicon glyphicon-cog"></span> Ganti password</a></li>
							<li role="separator" class="divider"></li>
							<li><a href="logout.php"><span class="glyphicon glyphicon-off"></span> Logout</a></li>


						</ul>
					</li>

				</ul>
			</div>
		</div>
	</div>
	<p><br/></p>
	<p><br/></p>
	<p><br/></p>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-2">
				<div id="get_category">
				</div>
				
				<div id="get_brand">
				</div>
				
			</div>
			<div class="col-md-8">	
				<div class="row">
					<div class="col-md-12 col-xs-12" id="product_msg">
					</div>
				</div>
				<div class="panel panel-primary" id="scroll">
					<div class="panel-heading"><strong>Produk</strong></div>
					<div class="panel-body">
						<div id="get_product">
							
						</div>
						
					</div>
					<div class="panel-footer" style="text-align: right">&copy; 2020 <a href="facebook.com/kumpulankode">kumpulankode.com</a></div>
				</div><hr>

				<ul class="pagination" id="pageno">
					
					<li><a href="#">1</a></li>
				</ul>
			</div>
			<div class="col-md-1"></div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="pull-right" style="margin-left: 50px">
					
				</div>
				
			</div>
		</div>
	</div>
</body>
</html>
















































