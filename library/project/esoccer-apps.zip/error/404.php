<?php

echo '<h1 align="center">Error 404 :(</h1>';

?>