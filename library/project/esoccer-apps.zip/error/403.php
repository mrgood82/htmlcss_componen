<?php

echo '<h1 align="center">Error 403 :(</h1>';

?>