# Live Search in PHP using AJAX

Hello coder✌,
I hope you are doing well.😎
The purpose of this project is to show the use of AJAX in Live Search in Database.
This is the simple project in PHP to perform the search operation on employee data table using AJAX.

## Video Tutorial 
https://youtu.be/XR8h21VFJ9c

## Connect
 1. Facebook     :     https://www.facebook.com/InvertBitt 
 2. twitter      :     https://twitter.com/InvertBitt 
 4. GitHub       :     https://github.com/ankesh06g
 5. LinkedIn     :     https://www.linkedin.com/in/aag06
