Cufon.replace('#slider .title, .button1', { fontFamily: 'Vegur', hover:true });
Cufon.replace('#menu a, h2, h3, #icons .first, .dropcap_1', { fontFamily: 'PT Sans', hover:true });

