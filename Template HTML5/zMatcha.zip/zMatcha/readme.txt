Designed by Zerotheme
Website : http://www.zerotheme.com
Zerogrid System for Responsive Design - http://www.zerotheme.com/zerogrid-a-simple-grid-system-for-responsive-design
Contact Form Ready to use - Open file contact.php and change your email.

/*----License----*/
+ You have the rights to use the resources for personal and commercial project(s) purposes.
+ You are not allowed to remove back link at the footer in template. You should contact us about this. http://www.zerotheme.com/contact-us
+ You are allowed to remove back link with basic templates. You can find basic templates at http://www.zerotheme.com/free-basic-responsive-html5-themes
+ You can not resell, redistribute, license, or sub-license any of the templates without direct permission from Zerotheme.com.
+ You are not allowed to provide direct link to download or preview template. You must link back to Zerotheme template page where users can find the download and preview template.